package com.example.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
	public class TaskService {

	    @Autowired
	    private TaskRepository taskRepository;

	    public List<Task> getAllTasks() {
			// TODO Auto-generated method stub
			List<Task> tasks = new ArrayList<Task>();
			taskRepository.findAll().forEach(tasks::add);			
		    return tasks;
		}

	    public Task getTaskById(Long id) {
	        return taskRepository.findById(id).orElse(null);
	    }

	    public Task createTask(Task task) {
	        return taskRepository.save(task);
	    }

	    public void updatetask(Task updatedtasked, Long id) {
			Optional<Task> existingTaskOptional = taskRepository.findById(id);
			if (existingTaskOptional.isPresent()) {
				Task existingTask = existingTaskOptional.get();
				existingTask.setName(updatedtasked.getName());
				existingTask.setDescription(updatedtasked.getDescription());
				taskRepository.save(existingTask);
			
			}
			
		}


	    public void deleteById(Long id) {
	        taskRepository.deleteById(id);
	    }
	}


