package com.example.demo;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin 

@RestController
	public class TaskController {

	    @Autowired
	    private TaskService taskService;
	    

    public TaskController(TaskService taskService) {
			super();
			this.taskService = taskService;
		}

	@GetMapping("gettask")

    public List<Task> getAllTasks() {
    	
        return taskService.getAllTasks();
    }

    @PostMapping("addtask")

    public void addtask(@RequestBody Task task)
    {
    	taskService.createTask(task);
    }
    
    @PutMapping("updatetask/{id}")
    public void updatetask(@RequestBody Task updatedtasked , @PathVariable Long id )
    {
    	taskService.updatetask(updatedtasked,id );

    }
    
    @DeleteMapping("deletetask/{id}")
    public void deletetask(@PathVariable Long id )
    {
    	taskService.deleteById(id);

    }
   

}



